﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using CodingAssignmentDeloitte.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CodingAssignmentDeloitte.Controllers
{    
    public class HomeController : Controller
    {
        static private List<User> users = new List<User>();
        static private List<Models.Task> tasks = new List<Models.Task>();
        static private List<long> taskIDs;
        private User userInfo;
        private User u;
        
        public HomeController()
        {
            if (users.Count == 0)
            {
                users.Add(new User { UserName = "user1", Password = "pass1" });
                users.Add(new User { UserName = "user2", Password = "pass2" });
                users.Add(new User { UserName = "user3", Password = "pass3" });                
            }
            if(tasks.Count == 0) { 
                tasks.Add(new Models.Task { Id = 1, TaskName = "Task name example 1", Username = "user1", TaskDescription = "Task description ...", LastUpdated = DateTime.Now, TaskChecked = false });
                tasks.Add(new Models.Task { Id = 2, TaskName = "Task name example 2", Username = "user1", TaskDescription = "Task description ...", LastUpdated = DateTime.Now, TaskChecked = false });
                tasks.Add(new Models.Task { Id = 3, TaskName = "Task name example 3", Username = "user2", TaskDescription = "Task description ...", LastUpdated = DateTime.Now, TaskChecked = false });
                tasks.Add(new Models.Task { Id = 4, TaskName = "Task name example 4", Username = "user1", TaskDescription = "Task description ...", LastUpdated = DateTime.Now, TaskChecked = false });
            }
        }            
        [HttpPost]
        public ActionResult Login(User userInfo)
        {            
            if (!ModelState.IsValid)
            {

            }
            else
            {
                this.userInfo = userInfo;
                //Adding login user to end of array. Only way i can find to persist it. This logs the user per session and deleted them after termination
                u = new User(userInfo.UserName, userInfo.Password);
                users.Add(u);                
                taskIDs = new List<long>();
                bool valid = false;
                foreach (var user in users)
                {
                    if (user.UserName == this.userInfo.UserName && user.Password == this.userInfo.Password)
                    {
                        valid = true;
                        foreach (var task in tasks)
                        {
                            if (task.Username == user.UserName)
                            {
                                taskIDs.Add(task.Id);
                                
                            }
                        }
                        SelectList list = new SelectList(taskIDs);
                        ViewBag.tasks = tasks;
                        ViewBag.taskIDs = list;
                        ViewBag.username = user.UserName;
                        ViewBag.userInfo = userInfo;
                        //If login is unsuccessful, return the user to enter details again, otherwise - show their tasks.
                        if (valid)
                        {
                            return View("Tasks");
                        }
                        else
                        {
                            return View("Index");
                        }
                    }
                }
                return BadRequest();
            }
            return BadRequest();
        }
              
        [HttpPost]
        //Called from Tasks page to create a new task.
        public ActionResult GoToCreate()
        {            
            return View("CreateTask");
        }
        //Called from CreateTask to submit the new task to memory and show it on the Tasks page
        public ActionResult CreateTask(Models.Task newTask)
        {
            if (ModelState.IsValid)
            {
                newTask.Username = users[users.Count - 1].UserName;
                newTask.LastUpdated = DateTime.Now;
                newTask.TaskChecked = false;
                tasks.Add(newTask);
                taskIDs = new List<long>();
                foreach (var user in users)
                {
                    //Getting login user from end of array
                    if (user.UserName == users[users.Count-1].UserName && user.Password == users[users.Count-1].Password)
                    {
                        foreach (var task1 in tasks)
                        {
                            if (task1.Username == user.UserName)
                            {
                                taskIDs.Add(task1.Id);
                            }
                        }
                        //Passing array + login information to Views for transparacy of tasks.
                        SelectList list = new SelectList(taskIDs);
                        ViewBag.tasks = tasks;
                        ViewBag.taskIDs = list;
                        ViewBag.username = user.UserName;
                        return View("Tasks");
                    }
                }
            }           
                return BadRequest();           
        }
        [HttpPost]
        //Removes a task based on the input from the dropdown menu
        public ActionResult RemoveTask()
        {
            if (!ModelState.IsValid)
            {
              
            }
            else
            {
                int sizeOfTasks = 0;
                foreach(var t1 in tasks)
                {
                    sizeOfTasks++;
                }
                String getTaskID = Request.Form["TaskIDs"].ToString();                
                for(int i = 0; i < sizeOfTasks; i++) 
                {
                    
                    if(tasks[i].Id == (long)Convert.ToDouble(getTaskID))
                    {
                        tasks.RemoveAt(i);
                        sizeOfTasks--;
                    }                    
                }
                taskIDs = new List<long>();
                foreach (var user in users)
                {
                    //Getting login user from end of array
                    if (user.UserName == users[users.Count - 1].UserName && user.Password == users[users.Count - 1].Password)
                    {
                        foreach (var task1 in tasks)
                        {
                            if (task1.Username == user.UserName)
                            {
                                taskIDs.Add(task1.Id);
                            }
                        }
                        SelectList list = new SelectList(taskIDs);
                        ViewBag.tasks = tasks;
                        ViewBag.taskIDs = list;
                        ViewBag.username = user.UserName;
                        return View("Tasks");
                    }
                }
            }
            return BadRequest();
        }     
        //Go to EditTask.cshtml and pass this information to be edited
        [HttpPost]
        public ActionResult EditTask()
        {
            if (!ModelState.IsValid)
            {

            }
            else
            {
                int sizeOfTasks = 0;
                foreach (var t1 in tasks)
                {
                    sizeOfTasks++;
                }
                String getTaskID = Request.Form["TaskIDs"].ToString();
                for (int i = 0; i < sizeOfTasks; i++)
                {

                    if (tasks[i].Id == (long)Convert.ToDouble(getTaskID))
                    {
                        Models.Task editTask = new Models.Task(tasks[i].Id, tasks[i].Username, tasks[i].TaskName, tasks[i].TaskDescription, tasks[i].LastUpdated, tasks[i].TaskChecked);
                        ViewBag.editTask = editTask;
                        return View("EditTask");
                    }
                }
            }
            return BadRequest();
            }
        
        //Information has just been edited and this method was called to ensure the information is correctly updated in memory and pushed to the page.
        public ActionResult EditedTask(Models.Task editedTask)
        {            
            int sizeOfTasks = 0;
            foreach (var t1 in tasks)
            {
                sizeOfTasks++;
            }
            editedTask.Username = users[users.Count-1].UserName;
            editedTask.LastUpdated = DateTime.Now;
            for (int i= 0;i<sizeOfTasks; i++)
            {
                if(tasks[i].Id == editedTask.Id)
                {
                    tasks[i] = editedTask;
                }
            }
            taskIDs = new List<long>();
            foreach (var user in users)
            {
                //Getting login user from end of array
                if (user.UserName == users[users.Count - 1].UserName && user.Password == users[users.Count - 1].Password)
                {
                    foreach (var task1 in tasks)
                    {
                        if (task1.Username == user.UserName)
                        {
                            taskIDs.Add(task1.Id);
                        }
                    }
                    SelectList list = new SelectList(taskIDs);
                    ViewBag.tasks = tasks;
                    ViewBag.taskIDs = list;
                    ViewBag.username = user.UserName;
                    return View("Tasks");
                }
            }
            return Ok();
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

    }
}
