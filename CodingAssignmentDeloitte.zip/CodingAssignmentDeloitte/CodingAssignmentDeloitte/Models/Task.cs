﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CodingAssignmentDeloitte.Models
{
    public class Task {
        public Task()
        {

        }
        public Task(long id, String UserName, String name, String desc, DateTime LastUpdated, bool TaskChecked)
        {
            this.Id = id;
            this.Username = UserName;
            this.TaskName = name;
            this.TaskDescription = desc;
            this.LastUpdated = LastUpdated;
            this.TaskChecked = TaskChecked;
        }
        [Key]
        [Display(Name = "ID")]
        public long Id { get; set; }
        [Display(Name = "User Name")]
        public String Username { get; set; }
        [Display(Name = "Task Name")]
        public String TaskName { get; set; }
        [Display(Name = "Description")]
        public String TaskDescription { get; set; }
        [Display(Name = "Last updated on: ")]
        public DateTime LastUpdated { get; set; }
        [Display(Name = "Task Completed? ")]
        public bool TaskChecked { get; set; }
    }
    
}
