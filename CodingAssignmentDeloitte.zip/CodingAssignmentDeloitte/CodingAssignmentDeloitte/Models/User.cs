﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CodingAssignmentDeloitte.Models
{
    public class User
    {
        public User()
        {

        }
        public User(String Username, String Password)
        {
            this.UserName = Username;
            this.Password = Password;
        }
        public long Id { get; set; }
        [Required]
        [Display(Name = "User name")]
        public String UserName { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public String Password { get; set; }
    }
}
