using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework.Internal;
using CodingAssignmentDeloitte.Models;
using CodingAssignmentDeloitte.Controllers;
using System;
using System.Collections.Generic;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        private static List<Task> tasks = new List<Task>();
        [TestMethod]
        public void TestMethodAddInstances()
        {                        
            User u = new User("Testuser123", "password123");
            Task t = new Task(1, u.UserName, "Name of task", "description of task", DateTime.Now, true);
            tasks.Add(t);
        }        
        [TestMethod]
        public void TestMethodPerformLoginAndRouting()
        {
            User u = new User("Testuser123", "password123");
            HomeController hc = new HomeController();
            hc.Login(u);            
            hc.GoToCreate();
            hc.CreateTask(new Task(2, u.UserName, "Name of task", "description of task", DateTime.Now, true));
        }
    }
}
